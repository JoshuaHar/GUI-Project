from tkinter import *
from tkinter.ttk import *
from PIL import Image, ImageTk
# This is where the submissions are checked
def submit():
    F1 = e1.get() # First name
    F2 = e2.get() # Last name
    R = e3.get() # Question
    if F1 == "" or F2 == "" or R == "":
        ErrorWindow()
        return
    else:
        Submitted = Toplevel(master)
        Submitted.title("Submitted")
        Label(Submitted, text='Application has been successfully submitted').grid(row=0)
        button = Button(Submitted, text='Exit', width=10, command=master.destroy).grid(row=1)
        image = Image.open("Eo_circle_green_checkmark.png")
        photo = ImageTk.PhotoImage(image)
        image_label = Label(Submitted, image=photo, text="Green circle with checkmark in it")
        image_label.photo = photo
        image_label.grid(row=2)
        f = open("Applications.txt", "a")
        f.write("\nName: " + F1 + " " + F2 + "\nWhy they want to work for us: " + R)
master = Tk()
# This is the error window which is called "Error" and acts as sort of a way to prevent accidental submissions
def ErrorWindow():
    Error = Toplevel(master)
    Error.title("Error")
    Label(Error, text='Error, not all fields have been filled out').grid(row=0)
    button = Button(Error, text='Return', width=10, command=Error.destroy).grid(row=2)
    image = Image.open("orange-error-icon-0.png")
    photo = ImageTk.PhotoImage(image)
    image_label = Label(Error, image=photo, text="Orange error symbol")
    image_label.photo = photo
    image_label.grid(row=3)
# This is the main window which is called "master"
Label(master, text='Please enter first and last name').grid(row=0)
Label(master, text='First Name').grid(row=1)
Label(master, text='Last Name').grid(row=2)
e1 = Entry(master)
e2 = Entry(master)
e1.grid(row=1, column=1)
e2.grid(row=2, column=1)
Label(master, text='Why are you interested in working for us?').grid(row=3)
e3 = Entry(master)
e3.grid(row=4)
button = Button(master, text='Stop', width=10, command=master.destroy).grid(row=5, column=0)
button1 = Button(master, text='Submit', width=10, command=submit).grid(row=5, column=1)
mainloop()